function Login() {
  return (
    <div>
      <h1>About Us</h1>
      <p>Learn more about the Batatas project and our mission to change the way we see money!</p>
    </div>
  );
}

export default Login;
