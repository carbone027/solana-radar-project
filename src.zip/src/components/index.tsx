import Header from "./Header";
import Hero from "./Hero";
import ContactUs from "./ContactUs";
import WhatAreWe from "./WhatAreWe";
import WhoAreWe from "./WhoAreWe";

export {
    Header,
    Hero,
    ContactUs,
    WhatAreWe,
    WhoAreWe
};